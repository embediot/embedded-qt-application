#include "backlight_ctrl/Backlight_Ctrl.h"


Backlight_Ctrl::Backlight_Ctrl()
{

}


Backlight_Ctrl::~Backlight_Ctrl()
{

}

void Backlight_Ctrl::set_brightness(char* level)
{
    QFile brightness_file(BACKLIGHT_BRIGHTNESS);

    brightness_file.open(QIODevice::ReadWrite);

    if(brightness_file.isOpen())
    {
        brightness_file.write(level);
    }

    brightness_file.close();
}

char Backlight_Ctrl::get_brightness(void)
{
    char backlight_level;

    QFile brightness_file(BACKLIGHT_ACTUAL_BRIGHTNESS);

    brightness_file.open(QIODevice::ReadOnly);

    if(brightness_file.isOpen())
    {
        brightness_file.read(&backlight_level,sizeof(backlight_level));
    }

    brightness_file.close();

    return backlight_level;
}
