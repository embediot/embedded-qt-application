#ifndef _BACKLIGHT_CTRL_H_
#define _BACKLIGHT_CTRL_H_

#include <QWidget>
#include <QDebug>
#include <QString>
#include <QByteArray>
#include <QFile>


#define    BRIGHTNESS_ZERO      0
#define    BRIGHTNESS_ONE       1
#define    BRIGHTNESS_TWO       2
#define    BRIGHTNESS_THREE     3
#define    BRIGHTNESS_FOUR      4
#define    BRIGHTNESS_FIVE      5
#define    BRIGHTNESS_SIX       6
#define    BRIGHTNESS_SEVEN     7



#define BACKLIGHT_BRIGHTNESS    "/sys/devices/platform/backlight/backlight/backlight/brightness"
#define BACKLIGHT_ACTUAL_BRIGHTNESS    "/sys/devices/platform/backlight/backlight/backlight/actual_brightness"

class Backlight_Ctrl : public QWidget
{
    Q_OBJECT

public:
    Backlight_Ctrl();
    ~Backlight_Ctrl();

    void set_brightness(char *level);
    char get_brightness(void);


private slots:


private:

};





#endif

