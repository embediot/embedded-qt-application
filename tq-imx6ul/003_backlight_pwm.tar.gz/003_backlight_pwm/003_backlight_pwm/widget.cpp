#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    backlight_ctrl = new Backlight_Ctrl();

    ui->pushButton_backlight_3->click();

    timer = new QTimer();
    connect( timer, SIGNAL(timeout()), this, SLOT(timer_timeout_handler()));
}

Widget::~Widget()
{
    delete ui;
}

void Widget::display_actual_brightness(char level)
{
    ui->lineEdit_backlight->setText(QString(level));
}

void Widget::timer_timeout_handler(void)
{
    ui->pushButton_backlight_5->click();
}

void Widget::on_pushButton_backlight_0_clicked()
{
    backlight_ctrl->set_brightness((char*)"0");

    timer->setSingleShot(true);
    timer->start(3000);
}

void Widget::on_pushButton_backlight_1_clicked()
{
    backlight_ctrl->set_brightness((char*)"1");

    display_actual_brightness(backlight_ctrl->get_brightness());
}

void Widget::on_pushButton_backlight_2_clicked()
{
    backlight_ctrl->set_brightness((char*)"2");
    display_actual_brightness(backlight_ctrl->get_brightness());
}

void Widget::on_pushButton_backlight_3_clicked()
{
    backlight_ctrl->set_brightness((char*)"3");
    display_actual_brightness(backlight_ctrl->get_brightness());
}

void Widget::on_pushButton_backlight_4_clicked()
{
    backlight_ctrl->set_brightness((char*)"4");
    display_actual_brightness(backlight_ctrl->get_brightness());
}

void Widget::on_pushButton_backlight_5_clicked()
{
    backlight_ctrl->set_brightness((char*)"5");
    display_actual_brightness(backlight_ctrl->get_brightness());
}

void Widget::on_pushButton_backlight_6_clicked()
{
    backlight_ctrl->set_brightness((char*)"6");
    display_actual_brightness(backlight_ctrl->get_brightness());
}

void Widget::on_pushButton_backlight_7_clicked()
{
    backlight_ctrl->set_brightness((char*)"7");
    display_actual_brightness(backlight_ctrl->get_brightness());
}
