#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTimer>
#include "backlight_ctrl/Backlight_Ctrl.h"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private slots:
    void on_pushButton_backlight_0_clicked();
    void on_pushButton_backlight_1_clicked();
    void on_pushButton_backlight_2_clicked();
    void on_pushButton_backlight_3_clicked();
    void on_pushButton_backlight_4_clicked();
    void on_pushButton_backlight_5_clicked();
    void on_pushButton_backlight_6_clicked();
    void on_pushButton_backlight_7_clicked();

    void timer_timeout_handler(void);
private:
    Ui::Widget *ui;
    Backlight_Ctrl *backlight_ctrl;
    QTimer *timer;
    void display_actual_brightness(char level);
};

#endif // WIDGET_H
