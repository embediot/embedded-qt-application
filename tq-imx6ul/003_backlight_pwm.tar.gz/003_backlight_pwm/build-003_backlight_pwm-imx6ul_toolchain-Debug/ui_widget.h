/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QLabel *label;
    QLineEdit *lineEdit_backlight;
    QPushButton *pushButton_backlight_0;
    QPushButton *pushButton_backlight_1;
    QPushButton *pushButton_backlight_2;
    QPushButton *pushButton_backlight_3;
    QPushButton *pushButton_backlight_4;
    QPushButton *pushButton_backlight_5;
    QPushButton *pushButton_backlight_6;
    QPushButton *pushButton_backlight_7;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(800, 480);
        label = new QLabel(Widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(200, 40, 201, 41));
        lineEdit_backlight = new QLineEdit(Widget);
        lineEdit_backlight->setObjectName(QString::fromUtf8("lineEdit_backlight"));
        lineEdit_backlight->setGeometry(QRect(410, 40, 61, 41));
        QFont font;
        font.setPointSize(17);
        lineEdit_backlight->setFont(font);
        pushButton_backlight_0 = new QPushButton(Widget);
        pushButton_backlight_0->setObjectName(QString::fromUtf8("pushButton_backlight_0"));
        pushButton_backlight_0->setGeometry(QRect(190, 120, 171, 41));
        pushButton_backlight_1 = new QPushButton(Widget);
        pushButton_backlight_1->setObjectName(QString::fromUtf8("pushButton_backlight_1"));
        pushButton_backlight_1->setGeometry(QRect(190, 190, 171, 41));
        pushButton_backlight_2 = new QPushButton(Widget);
        pushButton_backlight_2->setObjectName(QString::fromUtf8("pushButton_backlight_2"));
        pushButton_backlight_2->setGeometry(QRect(190, 260, 171, 41));
        pushButton_backlight_3 = new QPushButton(Widget);
        pushButton_backlight_3->setObjectName(QString::fromUtf8("pushButton_backlight_3"));
        pushButton_backlight_3->setGeometry(QRect(190, 330, 171, 41));
        pushButton_backlight_4 = new QPushButton(Widget);
        pushButton_backlight_4->setObjectName(QString::fromUtf8("pushButton_backlight_4"));
        pushButton_backlight_4->setGeometry(QRect(440, 120, 171, 41));
        pushButton_backlight_5 = new QPushButton(Widget);
        pushButton_backlight_5->setObjectName(QString::fromUtf8("pushButton_backlight_5"));
        pushButton_backlight_5->setGeometry(QRect(440, 190, 171, 41));
        pushButton_backlight_6 = new QPushButton(Widget);
        pushButton_backlight_6->setObjectName(QString::fromUtf8("pushButton_backlight_6"));
        pushButton_backlight_6->setGeometry(QRect(440, 260, 171, 41));
        pushButton_backlight_7 = new QPushButton(Widget);
        pushButton_backlight_7->setObjectName(QString::fromUtf8("pushButton_backlight_7"));
        pushButton_backlight_7->setGeometry(QRect(440, 330, 171, 41));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("Widget", "<html><head/><body><p><span style=\" font-size:18pt;\">current backlight: </span></p></body></html>", 0, QApplication::UnicodeUTF8));
        pushButton_backlight_0->setText(QApplication::translate("Widget", "BACKLIGHT_0", 0, QApplication::UnicodeUTF8));
        pushButton_backlight_1->setText(QApplication::translate("Widget", "BACKLIGHT_1", 0, QApplication::UnicodeUTF8));
        pushButton_backlight_2->setText(QApplication::translate("Widget", "BACKLIGHT_2", 0, QApplication::UnicodeUTF8));
        pushButton_backlight_3->setText(QApplication::translate("Widget", "BACKLIGHT_3", 0, QApplication::UnicodeUTF8));
        pushButton_backlight_4->setText(QApplication::translate("Widget", "BACKLIGHT_4", 0, QApplication::UnicodeUTF8));
        pushButton_backlight_5->setText(QApplication::translate("Widget", "BACKLIGHT_5", 0, QApplication::UnicodeUTF8));
        pushButton_backlight_6->setText(QApplication::translate("Widget", "BACKLIGHT_6", 0, QApplication::UnicodeUTF8));
        pushButton_backlight_7->setText(QApplication::translate("Widget", "BACKLIGHT_7", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
