#include "Led_Ctrl.h"

Led_Ctrl::Led_Ctrl()
{

}

//析构方法
Led_Ctrl::~Led_Ctrl()
{

}



void Led_Ctrl::led1_ctrl(unsigned char state)
{
    QFile led1_file(LED1_BRIGHTNESS);

    led1_file.open(QIODevice::ReadWrite);

    if(led1_file.isOpen())
    {
        if(state == LED_ON)
        {
            led1_file.write("0");
        }
        else if(state == LED_OFF)
        {
            led1_file.write("1");
        }
        else
        {

        }
    }
    else
    {

    }

    led1_file.close();
}

void Led_Ctrl::led2_ctrl(unsigned char state)
{
    QFile led2_file(LED2_BRIGHTNESS);

    led2_file.open(QIODevice::ReadWrite);

    if(led2_file.isOpen())
    {
        if(state == LED_ON)
        {
            led2_file.write("0");
        }
        else if(state == LED_OFF)
        {
            led2_file.write("1");
        }
        else
        {

        }
    }
    else
    {

    }

    led2_file.close();
}

void Led_Ctrl::led_trigger(const char *p_trigger)
{
    QFile led1_file(LED1_TRIGGER);
    QFile led2_file(LED2_TRIGGER);

    led1_file.open(QIODevice::ReadWrite);
    led2_file.open(QIODevice::ReadWrite);

    if(led1_file.isOpen())
    {
        led1_file.write(p_trigger);
    }
    else
    {

    }

    if(led2_file.isOpen())
    {
        led2_file.write(p_trigger);
    }
    else
    {

    }

    led1_file.close();
    led2_file.close();
}
