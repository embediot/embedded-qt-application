#ifndef _LED_CTRL_
#define _LED_CTRL_

#include <QWidget>
#include <QDebug>
#include <QString>
#include <QByteArray>
#include <QFile>

#define LED_ON      0x01
#define LED_OFF     0x02

#define LED1_BRIGHTNESS    "/sys/devices/platform/leds/leds/LED1/brightness"
#define LED2_BRIGHTNESS    "/sys/devices/platform/leds/leds/LED2/brightness"

#define LED1_TRIGGER       "/sys/devices/platform/leds/leds/LED1/trigger"
#define LED2_TRIGGER       "/sys/devices/platform/leds/leds/LED2/trigger"


#define TRIGGER_HEARTBEAT     "heartbeat"
#define TRIGGER_RC_FEEDBACK   "rc-feedback"
#define TRIGGER_NAND_DISK     "nand-disk"
#define TRIGGER_MMC0          "mmc0"
#define TRIGGER_TIMER         "timer"
#define TRIGGER_ONESHOT       "oneshot"
#define TRIGGER_BACKLIGHT     "backlight"
#define TRIGGER_GPIO          "gpio"
#define TRIGGER_NONE          "none"


class Led_Ctrl : public QWidget
{
    Q_OBJECT

public:
    Led_Ctrl();
    ~Led_Ctrl();

    void led1_ctrl(unsigned char state);
    void led2_ctrl(unsigned char state);

    void led_trigger(const char *p_trigger);

private slots:


private:

};
#endif

