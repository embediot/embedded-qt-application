#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    
    ui->pushButton_led1_on->setCheckable(false);
    ui->pushButton_led2_on->setCheckable(false);
    ui->pushButton_all_led_on->setCheckable(false);
    ui->pushButton_heartbeat->setCheckable(false);

    led_ctrl = new Led_Ctrl();

    led_ctrl->led1_ctrl(LED_OFF);
    led_ctrl->led2_ctrl(LED_OFF);
    led_ctrl->led_trigger(TRIGGER_NONE);
}

Widget::~Widget()
{
    delete led_ctrl;
    delete ui;
}

void Widget::on_pushButton_led1_on_clicked()
{
    qDebug() << ">>> on_pushButton_led1_on_clicked >>>";

    ui->pushButton_heartbeat->setCheckable(false);
    ui->pushButton_heartbeat->setText(trUtf8("HEARTBEAT"));
    led_ctrl->led_trigger(TRIGGER_NONE);


    if(ui->pushButton_led1_on->isCheckable())   //LED1 OFF
    {
        ui->pushButton_led1_on->setCheckable(false);
        ui->pushButton_led1_on->setText(trUtf8("LED1_ON"));

        led_ctrl->led1_ctrl(LED_OFF);
    }
    else      //LED1 ON
    {
        ui->pushButton_led1_on->setCheckable(true);
        ui->pushButton_led1_on->setText(trUtf8("LED1_OFF"));

        led_ctrl->led1_ctrl(LED_ON);
    }
}

void Widget::on_pushButton_led2_on_clicked()
{
    qDebug() << ">>> on_pushButton_led2_on_clicked >>>";

    ui->pushButton_heartbeat->setCheckable(false);
    ui->pushButton_heartbeat->setText(trUtf8("HEARTBEAT"));
    led_ctrl->led_trigger(TRIGGER_NONE);

    if(ui->pushButton_led2_on->isCheckable())   //LED2 OFF
    {
        ui->pushButton_led2_on->setCheckable(false);
        ui->pushButton_led2_on->setText(trUtf8("LED2_ON"));

        led_ctrl->led2_ctrl(LED_OFF);
    }
    else      //LED2 ON
    {
        ui->pushButton_led2_on->setCheckable(true);
        ui->pushButton_led2_on->setText(trUtf8("LED2_OFF"));

        led_ctrl->led2_ctrl(LED_ON);
    }
}

void Widget::on_pushButton_all_led_on_clicked()
{
    qDebug() << ">>> on_pushButton_all_led_on_clicked >>>";
    if(ui->pushButton_all_led_on->isCheckable())
    {
        ui->pushButton_all_led_on->setCheckable(false);
        ui->pushButton_all_led_on->setText(trUtf8("ALL_LED_ON"));

        led_ctrl->led1_ctrl(LED_OFF);
        led_ctrl->led2_ctrl(LED_OFF);
    }
    else
    {
        ui->pushButton_all_led_on->setCheckable(true);
        ui->pushButton_all_led_on->setText(trUtf8("ALL_LED_OFF"));

        led_ctrl->led1_ctrl(LED_ON);
        led_ctrl->led2_ctrl(LED_ON);
    }
}

void Widget::on_pushButton_heartbeat_clicked()
{
    qDebug() << ">>> on_pushButton_heartbeat_clicked >>>";

    if(ui->pushButton_heartbeat->isCheckable())
    {
        ui->pushButton_heartbeat->setCheckable(false);
        ui->pushButton_heartbeat->setText(trUtf8("HEARTBEAT"));

        led_ctrl->led_trigger(TRIGGER_NONE);
    }
    else
    {
        ui->pushButton_heartbeat->setCheckable(true);
        ui->pushButton_heartbeat->setText(trUtf8("STOP"));

        led_ctrl->led_trigger(TRIGGER_HEARTBEAT);
    }
}


