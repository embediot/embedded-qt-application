#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include "led_ctrl/Led_Ctrl.h"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private slots:
    void on_pushButton_led1_on_clicked();
    void on_pushButton_led2_on_clicked();
    void on_pushButton_all_led_on_clicked();
    void on_pushButton_heartbeat_clicked();

private:
    Ui::Widget *ui;

    Led_Ctrl *led_ctrl;
};

#endif // WIDGET_H
