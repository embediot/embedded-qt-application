/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QPushButton *pushButton_led1_on;
    QPushButton *pushButton_led2_on;
    QPushButton *pushButton_all_led_on;
    QPushButton *pushButton_heartbeat;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(800, 480);
        pushButton_led1_on = new QPushButton(Widget);
        pushButton_led1_on->setObjectName(QString::fromUtf8("pushButton_led1_on"));
        pushButton_led1_on->setGeometry(QRect(170, 90, 161, 61));
        pushButton_led2_on = new QPushButton(Widget);
        pushButton_led2_on->setObjectName(QString::fromUtf8("pushButton_led2_on"));
        pushButton_led2_on->setGeometry(QRect(170, 170, 161, 61));
        pushButton_all_led_on = new QPushButton(Widget);
        pushButton_all_led_on->setObjectName(QString::fromUtf8("pushButton_all_led_on"));
        pushButton_all_led_on->setGeometry(QRect(170, 250, 161, 61));
        pushButton_heartbeat = new QPushButton(Widget);
        pushButton_heartbeat->setObjectName(QString::fromUtf8("pushButton_heartbeat"));
        pushButton_heartbeat->setGeometry(QRect(450, 90, 161, 61));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", 0, QApplication::UnicodeUTF8));
        pushButton_led1_on->setText(QApplication::translate("Widget", "LED1_ON", 0, QApplication::UnicodeUTF8));
        pushButton_led2_on->setText(QApplication::translate("Widget", "LED2_ON", 0, QApplication::UnicodeUTF8));
        pushButton_all_led_on->setText(QApplication::translate("Widget", "ALL_LED_ON", 0, QApplication::UnicodeUTF8));
        pushButton_heartbeat->setText(QApplication::translate("Widget", "HEARTBEAT", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
