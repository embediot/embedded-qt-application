#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    m_obj = NULL;
    m_objThread = NULL;

    ui->progressBar->setRange(0,100);
    ui->progressBar->setValue(0);
    ui->progressBar_heart->setRange(0,100);
    ui->progressBar_heart->setValue(0);

    //启动一个定时器，用来监视ui线程是否有卡死
    connect(&m_heart,SIGNAL(timeout()),this,SLOT(heartTimeOut()));
    m_heart.setInterval(100);

    m_heart.start();   //启动定时器，不断更新heartbeat进度条

    //打印出 ui 的线程id
    receiveMessage(QString("%1->%2,current ui id is:%3").arg(__FUNCTION__).arg(__FILE__).arg((int)QThread::currentThreadId()));
}

Widget::~Widget()
{
    m_objThread->wait();    //等待线程执行完后再delete ui
    delete ui;
}

//更新进度条
void Widget::progress(int val)
{
    ui->progressBar->setValue(val); //在进度条显示进度
}

//接收并打印message信息
void Widget::receiveMessage(const QString &str)
{
    ui->textBrowser->append(str);//打印message信息
}

//这个定时器函数不断更新heartbeat进度条，用来显示ui线程没有被卡死
void Widget::heartTimeOut()
{
    static int s_heartCount = 0;
    ++s_heartCount;
    if(s_heartCount > 100)
    {
        s_heartCount = 0;
    }
    ui->progressBar_heart->setValue(s_heartCount);
}

//使用moveToThread的方式启动一个线程
void Widget::startObjThread()
{
    if(m_objThread)   //如果这个线程已经存在，则不再启动
    {
        return;
    }
    m_objThread= new QThread();    //创建一个QThread对象
    m_obj = new ThreadObject();    //使用继承于QObject的类创建一个对象
    m_obj->moveToThread(m_objThread);    //把继承于QObject的类对象转移到新的线程运行

    //关联deleteLater槽函数，这是线程安全退出的关键
    connect(m_objThread,SIGNAL(finished()),m_objThread,SLOT(deleteLater()));
    connect(m_objThread,SIGNAL(finished()),m_obj,SLOT(deleteLater()));

    //关联两个信号，用于启动线程里面的耗时操作
    connect(this,SIGNAL(startObjThreadWork1()),m_obj,SLOT(runSomeBigWork1()));
    connect(this,SIGNAL(startObjThreadWork2()),m_obj,SLOT(runSomeBigWork2()));

    //关联两个信号，用于更新进度条和打印信息
    connect(m_obj,SIGNAL(progress(int)),this,SLOT(progress(int)));
    connect(m_obj,SIGNAL(message(QString)),this,SLOT(receiveMessage(QString)));

    m_objThread->start();
}

//发送信号，唤起线程1的任务函数
void Widget::on_pushButton_moveToThread_run_1_clicked()
{
    if(!m_objThread)     //如果线程已经存在，则不用再start线程了
    {
        startObjThread();
    }

    emit startObjThreadWork1();//主线程通过信号换起子线程的槽函数

    ui->textBrowser->append("start Obj Thread work 1");
}

//发送信号，唤起线程2的任务函数
void Widget::on_pushButton_moveToThread_run_2_clicked()
{
    if(!m_objThread)  //如果线程已经存在，则不用再start线程了
    {
        startObjThread();
    }
    emit startObjThreadWork2();//主线程通过信号换起子线程的槽函数

    ui->textBrowser->append("start Obj Thread work 2");
}

void Widget::on_pushButton_stop_thread_run_clicked()
{
    if(m_objThread)
    {
        if(m_obj)
        {
            m_obj->stop();    //修改变量，停止线程运行
        }
    }
}

void Widget::on_pushButton_clear_broswer_clicked()
{
    ui->textBrowser->clear(); //清空显示窗口的内容
}
