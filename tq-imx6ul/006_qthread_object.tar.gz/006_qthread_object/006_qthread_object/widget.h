#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QDebug>
#include <QTimer>
#include "ThreadObject/ThreadObject.h"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
signals:
signals:
    void startObjThreadWork1();
    void startObjThreadWork2();

public slots:
    void on_pushButton_moveToThread_run_1_clicked();
    void on_pushButton_moveToThread_run_2_clicked();
    void on_pushButton_stop_thread_run_clicked();
    void on_pushButton_clear_broswer_clicked();

    void progress(int val);
    void receiveMessage(const QString &str);
    void heartTimeOut();
    void startObjThread();

private slots:


private:
    Ui::Widget *ui;
    QTimer m_heart;

    ThreadObject *m_obj;
    QThread *m_objThread;
};

#endif // WIDGET_H
