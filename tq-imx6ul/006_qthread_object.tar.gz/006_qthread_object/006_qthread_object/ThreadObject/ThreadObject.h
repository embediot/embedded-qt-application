#ifndef __THREAD_OBJECT_H_
#define __THREAD_OBJECT_H_

#include <QObject>
#include <QMutex>
#include <QThread>
#include <QDebug>
#include <QElapsedTimer>
#include <limits>

class ThreadObject : public QObject
{
    Q_OBJECT

signals:
    void message(const QString& info);  //通过此信号，发送需要打印的message消息
    void progress(int present);  //通过此信号，发送ProgressBar的进度百分比

public:
    ThreadObject(QObject* parent = NULL);
    ~ThreadObject();
    void setRunCount(int count);  //设置运行次数
    void stop();


public slots:
    void runSomeBigWork1();     //线程的while循环，在里面执行耗时任务
    void runSomeBigWork2();      //线程的while循环，在里面执行耗时任务

private:
    int m_runCount;       //while循环的运行次数
    int m_runCount2;      //while循环的运行次数
    bool m_isStop;        //线程停止标志位

    QMutex m_stopMutex;

    void msleep(unsigned int msec);  //线程休眠函数
};


#endif

