/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QProgressBar>
#include <QtGui/QPushButton>
#include <QtGui/QTextBrowser>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QProgressBar *progressBar_heart;
    QPushButton *pushButton_moveToThread_run_1;
    QLabel *label;
    QLabel *label_2;
    QProgressBar *progressBar;
    QTextBrowser *textBrowser;
    QPushButton *pushButton_moveToThread_run_2;
    QPushButton *pushButton_stop_thread_run;
    QPushButton *pushButton_clear_broswer;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(800, 480);
        progressBar_heart = new QProgressBar(Widget);
        progressBar_heart->setObjectName(QString::fromUtf8("progressBar_heart"));
        progressBar_heart->setGeometry(QRect(120, 130, 641, 23));
        progressBar_heart->setValue(24);
        pushButton_moveToThread_run_1 = new QPushButton(Widget);
        pushButton_moveToThread_run_1->setObjectName(QString::fromUtf8("pushButton_moveToThread_run_1"));
        pushButton_moveToThread_run_1->setGeometry(QRect(40, 30, 151, 61));
        label = new QLabel(Widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 130, 71, 21));
        label_2 = new QLabel(Widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(60, 160, 51, 21));
        progressBar = new QProgressBar(Widget);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setGeometry(QRect(120, 160, 641, 23));
        progressBar->setValue(24);
        textBrowser = new QTextBrowser(Widget);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(20, 191, 761, 241));
        pushButton_moveToThread_run_2 = new QPushButton(Widget);
        pushButton_moveToThread_run_2->setObjectName(QString::fromUtf8("pushButton_moveToThread_run_2"));
        pushButton_moveToThread_run_2->setGeometry(QRect(230, 30, 151, 61));
        pushButton_stop_thread_run = new QPushButton(Widget);
        pushButton_stop_thread_run->setObjectName(QString::fromUtf8("pushButton_stop_thread_run"));
        pushButton_stop_thread_run->setGeometry(QRect(420, 30, 151, 61));
        pushButton_clear_broswer = new QPushButton(Widget);
        pushButton_clear_broswer->setObjectName(QString::fromUtf8("pushButton_clear_broswer"));
        pushButton_clear_broswer->setGeometry(QRect(610, 30, 151, 61));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "QObject Thread", 0, QApplication::UnicodeUTF8));
        pushButton_moveToThread_run_1->setText(QApplication::translate("Widget", "moveToThread run 1", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("Widget", "heartbeat", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("Widget", "thread", 0, QApplication::UnicodeUTF8));
        pushButton_moveToThread_run_2->setText(QApplication::translate("Widget", "moveToThread run 2", 0, QApplication::UnicodeUTF8));
        pushButton_stop_thread_run->setText(QApplication::translate("Widget", "stop thread run", 0, QApplication::UnicodeUTF8));
        pushButton_clear_broswer->setText(QApplication::translate("Widget", "Clear Browser", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
