#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    ui->pushButton_open_uart->setCheckable(false);

    uart_test = new Uart_Test();

    connect(uart_test, SIGNAL(read_serial_signals(QByteArray)), this, SLOT(slot_serialport_data_process(QByteArray)));
}

Widget::~Widget()
{
    delete uart_test;
    delete ui;
}

void Widget::on_pushButton_open_uart_clicked()
{
    QString port_num;
    QString baudrate;

    port_num = ui->comboBox_port->currentText();
    baudrate = ui->comboBox_baudrate->currentText();

    if(ui->pushButton_open_uart->isCheckable())
    {
        ui->comboBox_baudrate->setEnabled(true);
        ui->comboBox_port->setEnabled(true);
        ui->pushButton_open_uart->setCheckable(false);
        ui->pushButton_open_uart->setText(trUtf8("OPEN"));

        uart_test->close_serial_port();
    }
    else
    {
        if(uart_test->open_serial_port(port_num,baudrate))
        {
            ui->comboBox_baudrate->setEnabled(false);
            ui->comboBox_port->setEnabled(false);
            ui->pushButton_open_uart->setCheckable(true);
            ui->pushButton_open_uart->setText(trUtf8("CLOSE"));
        }
        else
        {

        }
    }
}

void Widget::on_pushButton_tx_clear_clicked()
{
    ui->textBrowser_txdata->clear();
}

void Widget::on_pushButton_rx_clear_clicked()
{
    ui->textBrowser_rxdata->clear();
}

void Widget::on_pushButton_send_data_clicked()
{
    uart_test->write_serial_port((char*)"helloworld\n",sizeof("helloworld\n"));

    display_uart_tx_data(QString("helloworld"));
}

void Widget::slot_serialport_data_process(QByteArray arr)
{
    char data_out[1024];

    memset(data_out,0x00,sizeof(data_out));
    byte_to_str(arr.data(),data_out,arr.length());

    display_uart_rx_data(QString(data_out));
}

void Widget::display_uart_tx_data(QString str_data)
{
    //QString str_display = "[device --> pc] ";
    ui->textBrowser_txdata->append(str_data);
}

void Widget::display_uart_rx_data(QString str_data)
{
    //QString str_display = "[pc --> device] ";
    ui->textBrowser_rxdata->append(str_data);
}

/******************************
        格式化函数
******************************/
//16进制转换
char *Widget::byte_to_str(char *p_in, char *p_out, int len)
{
    char *pstr = p_out;
    unsigned char *p = (unsigned char *) p_in;

    int i = 0;
    for (i = 0; i < len; i++, pstr += 3)
        sprintf(pstr, "%02x ", *p++);

    return p_out;
}

//字符串转换为16进制
int Widget::str_to_hex(unsigned char *buf, unsigned char *hex, int sLen)
{
    unsigned char tHex = 0x00;
    unsigned char *tBuf = (unsigned char *) malloc(sizeof(unsigned char) * 8);
    memset(tBuf, '\0', 8);
    int i = 0;
    for (i = 0; i < sLen; i += 2)
    {
        memcpy(tBuf, &buf[i], 2);
        tHex = (unsigned char) strtol((char *) tBuf, NULL, 16);
        hex[i / 2] = tHex;
    }
    return sLen / 2;
}



