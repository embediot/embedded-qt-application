#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include "uart_test/Uart_Test.h"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private slots:
    void on_pushButton_open_uart_clicked();
    void on_pushButton_tx_clear_clicked();
    void on_pushButton_rx_clear_clicked();

    void slot_serialport_data_process(QByteArray arr);

    void on_pushButton_send_data_clicked();

private:
    Ui::Widget *ui;
    Uart_Test *uart_test;

    void display_uart_tx_data(QString str_data);
    void display_uart_rx_data(QString str_data);

    char *byte_to_str(char *p_in, char *p_out, int len);
    int str_to_hex(unsigned char *buf, unsigned char *hex, int sLen);
};

#endif // WIDGET_H
