#ifndef _UART_TEST_H_
#define _UART_TEST_H_

#include <QWidget>
#include <QDebug>
#include <QString>
#include <QByteArray>
#include <QFile>
#include <QTimer>
//#include "qextserialport/qextserialport.h"
//#include "qextserialport/qextserialbase.h"
#include "qextserialport/posix_qextserialport.h"


class Uart_Test : public QWidget
{
    Q_OBJECT

public:
    Uart_Test();
    ~Uart_Test();

    bool open_serial_port(QString port,QString baud);
    bool close_serial_port(void);
    void write_serial_port(char *p_data,int len);
    void write_serial_port(QByteArray arr);

signals:
    void read_serial_signals(QByteArray arr);

private slots:
    void slot_read_serial_port();

private:
    QString port_name;
    BaudRateType baudrate;
    QTimer *recv_timeout_timer;
    Posix_QextSerialPort *serial_port;
    QByteArray recv_data;
    BaudRateType get_baudrate(QString baudrate);
    unsigned int serial_port_recv_len;
};



#endif

