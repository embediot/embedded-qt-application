#include "uart_test/Uart_Test.h"


Uart_Test::Uart_Test()
{

}


Uart_Test::~Uart_Test()
{
    close_serial_port();

}

//获取波特率
BaudRateType Uart_Test::get_baudrate(QString baudrate)
{
    bool ok;
    int baud = baudrate.toInt(&ok,10);
    BaudRateType baud_ret = BAUD9600;

    switch(baud)
    {
        case 4800:
            baud_ret = BAUD4800;
        break;
        case 9600:
            baud_ret = BAUD9600;
        break;
        case 19200:
            baud_ret = BAUD19200;
        break;
        case 38400:
            baud_ret = BAUD38400;
        break;
        case 57600:
            baud_ret = BAUD57600;
        break;
        case 115200:
            baud_ret = BAUD115200;
        break;
        case 128000:
            baud_ret = BAUD128000;
        break;
        default:
            baud_ret = BAUD9600;
        break;
    }

    return baud_ret;
}

bool Uart_Test::open_serial_port(QString port,QString baud)
{
    this->port_name = QString("/dev/")+port;
    this->baudrate = get_baudrate(baud);

    serial_port = new Posix_QextSerialPort(port_name,QextSerialBase::Polling);

    if(serial_port->open(QIODevice::ReadWrite))
    {
        serial_port->setBaudRate(baudrate);
        serial_port->setDataBits(DATA_8);
        serial_port->setParity(PAR_NONE);
        serial_port->setStopBits(STOP_1);
        serial_port->setFlowControl(FLOW_OFF);
        serial_port->setTimeout(1);

        recv_timeout_timer = new QTimer();
        connect( recv_timeout_timer, SIGNAL(timeout()), this, SLOT(slot_read_serial_port()));
        recv_timeout_timer->start(100);
        return true;
    }

    return false;
}

bool Uart_Test::close_serial_port(void)
{
    if(serial_port->isOpen())
    {
        serial_port->close();
    }

    delete serial_port;
    serial_port = NULL;

    recv_timeout_timer->stop();
    delete recv_timeout_timer;
    recv_timeout_timer = NULL;

    return true;
}

void Uart_Test::write_serial_port(char *p_data,int len)
{
    if(serial_port->isOpen())
    {
        if(len)serial_port->write(p_data,len);
    }
}

void Uart_Test::write_serial_port(QByteArray arr)
{
    if(serial_port->isOpen())
    {
        serial_port->write(arr);
    }
}

void Uart_Test::slot_read_serial_port()
{
    if(serial_port->bytesAvailable() > 0)
    {
        recv_data.clear();
        recv_data = serial_port->readAll();

        emit read_serial_signals(recv_data);
    }
}




