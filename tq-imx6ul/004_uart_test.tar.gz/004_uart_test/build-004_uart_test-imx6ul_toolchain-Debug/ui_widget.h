/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QTextBrowser>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QLabel *label_title;
    QLabel *label_port;
    QLabel *label_baudrate;
    QComboBox *comboBox_port;
    QComboBox *comboBox_baudrate;
    QPushButton *pushButton_open_uart;
    QLabel *label_txdata;
    QLabel *label_rxdata;
    QTextBrowser *textBrowser_txdata;
    QTextBrowser *textBrowser_rxdata;
    QPushButton *pushButton_tx_clear;
    QPushButton *pushButton_rx_clear;
    QPushButton *pushButton_send_data;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(800, 480);
        label_title = new QLabel(Widget);
        label_title->setObjectName(QString::fromUtf8("label_title"));
        label_title->setGeometry(QRect(0, 0, 801, 41));
        label_port = new QLabel(Widget);
        label_port->setObjectName(QString::fromUtf8("label_port"));
        label_port->setGeometry(QRect(120, 40, 61, 31));
        label_baudrate = new QLabel(Widget);
        label_baudrate->setObjectName(QString::fromUtf8("label_baudrate"));
        label_baudrate->setGeometry(QRect(320, 40, 101, 31));
        comboBox_port = new QComboBox(Widget);
        comboBox_port->setObjectName(QString::fromUtf8("comboBox_port"));
        comboBox_port->setGeometry(QRect(190, 40, 111, 31));
        comboBox_baudrate = new QComboBox(Widget);
        comboBox_baudrate->setObjectName(QString::fromUtf8("comboBox_baudrate"));
        comboBox_baudrate->setGeometry(QRect(430, 40, 91, 31));
        pushButton_open_uart = new QPushButton(Widget);
        pushButton_open_uart->setObjectName(QString::fromUtf8("pushButton_open_uart"));
        pushButton_open_uart->setGeometry(QRect(570, 40, 91, 31));
        label_txdata = new QLabel(Widget);
        label_txdata->setObjectName(QString::fromUtf8("label_txdata"));
        label_txdata->setGeometry(QRect(40, 80, 81, 31));
        label_rxdata = new QLabel(Widget);
        label_rxdata->setObjectName(QString::fromUtf8("label_rxdata"));
        label_rxdata->setGeometry(QRect(430, 80, 81, 31));
        textBrowser_txdata = new QTextBrowser(Widget);
        textBrowser_txdata->setObjectName(QString::fromUtf8("textBrowser_txdata"));
        textBrowser_txdata->setGeometry(QRect(40, 110, 331, 261));
        textBrowser_rxdata = new QTextBrowser(Widget);
        textBrowser_rxdata->setObjectName(QString::fromUtf8("textBrowser_rxdata"));
        textBrowser_rxdata->setGeometry(QRect(430, 110, 331, 261));
        pushButton_tx_clear = new QPushButton(Widget);
        pushButton_tx_clear->setObjectName(QString::fromUtf8("pushButton_tx_clear"));
        pushButton_tx_clear->setGeometry(QRect(280, 80, 91, 25));
        pushButton_rx_clear = new QPushButton(Widget);
        pushButton_rx_clear->setObjectName(QString::fromUtf8("pushButton_rx_clear"));
        pushButton_rx_clear->setGeometry(QRect(670, 80, 91, 25));
        pushButton_send_data = new QPushButton(Widget);
        pushButton_send_data->setObjectName(QString::fromUtf8("pushButton_send_data"));
        pushButton_send_data->setGeometry(QRect(170, 380, 201, 41));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "SerialPort", 0, QApplication::UnicodeUTF8));
        label_title->setText(QApplication::translate("Widget", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; font-weight:600;\">Serial Port Test</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_port->setText(QApplication::translate("Widget", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">PORT :</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_baudrate->setText(QApplication::translate("Widget", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">BAUDRATE :</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        comboBox_port->clear();
        comboBox_port->insertItems(0, QStringList()
         << QApplication::translate("Widget", "ttySAC1", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Widget", "ttySAC2", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Widget", "ttySAC3", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Widget", "ttySAC4", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Widget", "ttySAC5", 0, QApplication::UnicodeUTF8)
        );
        comboBox_baudrate->clear();
        comboBox_baudrate->insertItems(0, QStringList()
         << QApplication::translate("Widget", "2400", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Widget", "4800", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Widget", "9600", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Widget", "19200", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Widget", "38400", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Widget", "115200", 0, QApplication::UnicodeUTF8)
        );
        pushButton_open_uart->setText(QApplication::translate("Widget", "OPEN", 0, QApplication::UnicodeUTF8));
        label_txdata->setText(QApplication::translate("Widget", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">TX_DATA :</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_rxdata->setText(QApplication::translate("Widget", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">RX_DATA :</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        pushButton_tx_clear->setText(QApplication::translate("Widget", "TX_CLEAR", 0, QApplication::UnicodeUTF8));
        pushButton_rx_clear->setText(QApplication::translate("Widget", "RX_CLEAR", 0, QApplication::UnicodeUTF8));
        pushButton_send_data->setText(QApplication::translate("Widget", "send data", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
