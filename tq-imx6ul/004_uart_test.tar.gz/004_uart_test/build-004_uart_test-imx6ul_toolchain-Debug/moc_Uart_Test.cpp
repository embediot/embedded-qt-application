/****************************************************************************
** Meta object code from reading C++ file 'Uart_Test.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../004_uart_test/uart_test/Uart_Test.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Uart_Test.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Uart_Test[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      15,   11,   10,   10, 0x05,

 // slots: signature, parameters, type, tag, flags
      47,   10,   10,   10, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_Uart_Test[] = {
    "Uart_Test\0\0arr\0read_serial_signals(QByteArray)\0"
    "slot_read_serial_port()\0"
};

void Uart_Test::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        Uart_Test *_t = static_cast<Uart_Test *>(_o);
        switch (_id) {
        case 0: _t->read_serial_signals((*reinterpret_cast< QByteArray(*)>(_a[1]))); break;
        case 1: _t->slot_read_serial_port(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData Uart_Test::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject Uart_Test::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_Uart_Test,
      qt_meta_data_Uart_Test, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Uart_Test::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Uart_Test::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Uart_Test::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Uart_Test))
        return static_cast<void*>(const_cast< Uart_Test*>(this));
    return QWidget::qt_metacast(_clname);
}

int Uart_Test::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void Uart_Test::read_serial_signals(QByteArray _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
