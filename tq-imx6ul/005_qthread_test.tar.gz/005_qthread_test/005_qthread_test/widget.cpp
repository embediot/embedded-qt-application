#include "widget.h"
#include "ui_widget.h"


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    //控件初始化
    ui->progressBar->setRange(0,100);
    ui->progressBar->setValue(0);
    ui->progressBar_heart->setRange(0,100);
    ui->progressBar_heart->setValue(0);

    connect(ui->pushButton_qthread1,SIGNAL(clicked()),this,SLOT(onButtonQThreadClicked()));
    connect(ui->pushButton_qthread1_setSomething,SIGNAL(clicked()),this,SLOT(onButtonQthread1SetSomethingClicked()));
    connect(ui->pushButton_qthread1_getSomething,SIGNAL(clicked()),this,SLOT(onButtonQthread1GetSomethingClicked()));
    connect(ui->pushButton_qthreadQuit,SIGNAL(clicked()),this,SLOT(onButtonQthreadQuitClicked()));
    connect(ui->pushButton_qthreadTerminate,SIGNAL(clicked()),this,SLOT(onButtonQthreadTerminateClicked()));
    connect(ui->pushButton_qthreadExit,SIGNAL(clicked()),this,SLOT(onButtonQThreadExitClicked()));
    connect(ui->pushButton_doSomthing,SIGNAL(clicked()),this,SLOT(onButtonQThreadDoSomthingClicked()));
    connect(ui->pushButton_clear_broswer,SIGNAL(clicked()),this,SLOT(onButtonClearBroswerClicked()));
    connect(ui->pushButton_qthreadRunLocal,SIGNAL(clicked()),this,SLOT(onButtonQThreadRunLoaclClicked()));
    //connect(ui->pushButton_qobjectStart,&QPushButton::clicked,this,&Widget::onButtonObjectMove2ThreadClicked);
    //connect(ui->pushButton_objQuit,&QPushButton::clicked,this,&Widget::onButtonObjectQuitClicked);
        //
    connect(&m_heart,SIGNAL(timeout()),this,SLOT(heartTimeOut()));
    m_heart.setInterval(100);

    //在这里创建了一个全局线程
    m_thread = new ThreadFromQThread(this);
    connect(m_thread,SIGNAL(message(QString)),this,SLOT(receiveMessage(QString)));  //接收message信号，在窗口打印线程信息
    connect(m_thread,SIGNAL(progress(int)),this,SLOT(progress(int)));//接收progress信号，更新进度条
    connect(m_thread,SIGNAL(finished()),this,SLOT(onQThreadFinished()));//接收线程结束信号，打印线程结束的消息

    m_heart.start();   //启动定时器，不断更新heartbeat进度条

    m_currentRunLoaclThread = NULL;
}


Widget::~Widget()
{
    qDebug() << "start destroy widget";
    m_thread->stopImmediately();//由于此线程的父对象是Widget，因此退出时需要进行判断
    m_thread->wait();   //在这里，会阻塞等待线程执行完
    delete ui;
    qDebug() << "end destroy widget";
}

void Widget::onButtonClearBroswerClicked()
{
    ui->textBrowser->clear(); //清空显示窗口的内容
}

void Widget::onButtonQThreadClicked()
{
    ui->progressBar->setValue(0);
    if(m_thread->isRunning())  //判断线程是否已经在运行
    {
        return;
    }
    m_thread->start();   //启动线程，执行线程的run()函数
}

void Widget::progress(int val)
{
    ui->progressBar->setValue(val); //在进度条显示进度
}

void Widget::receiveMessage(const QString &str)
{
    ui->textBrowser->append(str);//打印message信息
}

//这个定时器函数不断更新heartbeat进度条，用来显示ui线程没有被卡死
void Widget::heartTimeOut()
{
    static int s_heartCount = 0;
    ++s_heartCount;
    if(s_heartCount > 100)
    {
        s_heartCount = 0;
    }
    ui->progressBar_heart->setValue(s_heartCount);
}

//线程结束后，在窗口打印信息
void Widget::onQThreadFinished()
{
    ui->textBrowser->append("ThreadFromQThread finish");
}

void Widget::onButtonQthread1SetSomethingClicked()
{
    m_thread->setSomething();//在ui线程中，调用这个函数，这个函数打印来的线程ID是ui的线程ID
}

void Widget::onButtonQthread1GetSomethingClicked()
{
    m_thread->getSomething();//在ui线程中，调用这个函数，这个函数打印来的线程ID是ui的线程ID
}

void Widget::onButtonQThreadDoSomthingClicked()
{
    m_thread->doSomething();  //在ui线程中，调用这个函数，这个函数打印来的线程ID是ui的线程ID
}

void Widget::onButtonQthreadQuitClicked()
{
    ui->textBrowser->append("m_thread->quit() but not work");
    m_thread->quit();
}

void Widget::onButtonQthreadTerminateClicked()
{
    //m_thread->terminate();   //调用这个函数，强制退出线程，不建议使用
    m_thread->stopImmediately(); //调用这个函数，安全退出线程
}

void Widget::onButtonQThreadExitClicked()
{
    m_thread->exit();
}

//这个函数用来创建局部线程，所谓局部线程，就是运行完后，自动销毁的线程
void Widget::onButtonQThreadRunLoaclClicked()
{
    //判断这个局部线程是否已经存在，如果已经存在，则先退出
    if(m_currentRunLoaclThread)
    {
         m_currentRunLoaclThread->stopImmediately();
    }

    ThreadFromQThread* thread = new ThreadFromQThread(NULL);//这里父对象指定为NULL
    connect(thread,SIGNAL(message(QString)),this,SLOT(receiveMessage(QString)));//接收message信号，在窗口打印线程信息
    connect(thread,SIGNAL(progress(int)),this,SLOT(progress(int)));//接收progress信号，更新进度条
    connect(thread,SIGNAL(finished()),this,SLOT(onQThreadFinished()));//接收线程结束信号，打印线程结束的消息
    connect(thread,SIGNAL(finished()),thread,SLOT(deleteLater()));//线程结束后调用deleteLater来销毁分配的内存
    //线程销毁时，会发送destroyed信号，然后把临时变量再次赋值为NULL
    connect(thread,SIGNAL(destroyed(QObject*)),this,SLOT(onLocalThreadDestroy(QObject*)));
    thread->start();//启动线程，执行run()函数
    m_currentRunLoaclThread = thread;  //保存当前正在运行的线程

}

//局部线程销毁函数，
void Widget::onLocalThreadDestroy(QObject *obj)
{
    if(qobject_cast<QObject*>(m_currentRunLoaclThread) == obj)
    {
        m_currentRunLoaclThread = NULL;
    }
}
