#include "ThreadFromQThread.h"
#include <QDebug>


ThreadFromQThread::ThreadFromQThread(QObject* par) : QThread(par)
,m_runCount(20),m_isCanRun(true)
{

}

ThreadFromQThread::~ThreadFromQThread()
{
    qDebug() << "ThreadFromQThread::~ThreadFromQThread()";
}

//通过发送message信号，打印调用此函数的线程ID
void ThreadFromQThread::setSomething()
{
    msleep(500);
    QString str = QString("%1->%2,thread id:%3").arg(__FUNCTION__).arg(__FILE__).arg((int)QThread::currentThreadId());
    emit message(str);
}

//通过发送message信号，打印调用此函数的线程ID
void ThreadFromQThread::getSomething()
{
    msleep(500);
    emit message(QString("%1->%2,thread id:%3").arg(__FUNCTION__).arg(__FILE__).arg((int)QThread::currentThreadId()));
}

//设置run()函数的循环次数
void ThreadFromQThread::setRunCount(int count)
{
    m_runCount = count;
    emit message(QString("%1->%2,thread id:%3").arg(__FUNCTION__).arg(__FILE__).arg((int)QThread::currentThreadId()));
}

//线程处理任务的函数体，这个run函数会在一个新的线程里运行
void ThreadFromQThread::run()
{
    int count = 0;
    QString str = QString("%1->%2,thread id:%3").arg(__FILE__).arg(__FUNCTION__).arg((int)QThread::currentThreadId());
    emit message(str);

    m_isCanRun = true;

    while(1)
    {
        sleep(1);
        ++count;
        emit progress(((float)count / m_runCount) * 100); //发送进度条百分比
        emit message(QString("ThreadFromQThread::run times:%1").arg(count));  //打印已运行的次数
        doSomething();  //打印线程的具体信息
        if(m_runCount == count)   //如果等于线程最大的运行次数，则退出
        {
            break;
        }

        //在下面的函数体内，安全退出线程
        {
            QMutexLocker locker(&m_lock);
            if(!m_isCanRun)//在每次循环判断是否可以运行，如果不行就退出循环
            {
                return;
            }
        }
    }
}

void ThreadFromQThread::doSomething()
{
    msleep(500);
    emit message(QString("%1->%2,thread id:%3").arg(__FUNCTION__).arg(__FILE__).arg((int)QThread::currentThreadId()));
}

void ThreadFromQThread::stopImmediately()
{
    {
        QMutexLocker locker(&m_lock);
        m_isCanRun = false;
    }
}
