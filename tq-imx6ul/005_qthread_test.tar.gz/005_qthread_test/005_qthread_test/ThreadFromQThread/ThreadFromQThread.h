#ifndef THREADFROMQTHREAD_H
#define THREADFROMQTHREAD_H
#include <QThread>
#include <QMutex>

class ThreadFromQThread : public QThread
{
    Q_OBJECT

signals:
    void message(const QString& info);  //通过此信号，发送需要打印的message消息
    void progress(int present);  //通过此信号，发送ProgressBar的进度百分比

public slots:
    void stopImmediately();   //调用此槽函数，结束进程

public:
    ThreadFromQThread(QObject* par);
    ~ThreadFromQThread();
    void setSomething();   //发送message信号，打印某些信息
    void getSomething();   //发送message信号，打印某些信息
    void setRunCount(int count);  //设置run()函数的循环次数
    void run();           //重载run()函数
    void doSomething();   //循环打印某些信息

private:
    int m_runCount;
    QMutex m_lock;
    bool m_isCanRun;

};

#endif // THREADFROMQTHREAD_H
