#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include "ThreadFromQThread/ThreadFromQThread.h"
#include <QDebug>
#include <QTimer>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

public slots:
    void onButtonQThreadClicked();
    void onButtonClearBroswerClicked();
    void onButtonQthread1SetSomethingClicked();
    void onButtonQthread1GetSomethingClicked();
    void onButtonQthreadQuitClicked();
    void onButtonQthreadTerminateClicked();
    void onButtonQThreadDoSomthingClicked();
    void onButtonQThreadExitClicked();
    void onButtonQThreadRunLoaclClicked();
    void progress(int val);
    void receiveMessage(const QString &str);
    void heartTimeOut();
    void onQThreadFinished();
    void onLocalThreadDestroy(QObject* obj);



private:
    Ui::Widget *ui;

    QTimer m_heart;
    ThreadFromQThread *m_thread;
    ThreadFromQThread *m_currentRunLoaclThread;
};

#endif // WIDGET_H
