/****************************************************************************
** Meta object code from reading C++ file 'widget.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../005_qthread_test/widget.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'widget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Widget[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
       8,    7,    7,    7, 0x0a,
      33,    7,    7,    7, 0x0a,
      63,    7,    7,    7, 0x0a,
     101,    7,    7,    7, 0x0a,
     139,    7,    7,    7, 0x0a,
     168,    7,    7,    7, 0x0a,
     202,    7,    7,    7, 0x0a,
     237,    7,    7,    7, 0x0a,
     266,    7,    7,    7, 0x0a,
     303,  299,    7,    7, 0x0a,
     321,  317,    7,    7, 0x0a,
     345,    7,    7,    7, 0x0a,
     360,    7,    7,    7, 0x0a,
     384,  380,    7,    7, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_Widget[] = {
    "Widget\0\0onButtonQThreadClicked()\0"
    "onButtonClearBroswerClicked()\0"
    "onButtonQthread1SetSomethingClicked()\0"
    "onButtonQthread1GetSomethingClicked()\0"
    "onButtonQthreadQuitClicked()\0"
    "onButtonQthreadTerminateClicked()\0"
    "onButtonQThreadDoSomthingClicked()\0"
    "onButtonQThreadExitClicked()\0"
    "onButtonQThreadRunLoaclClicked()\0val\0"
    "progress(int)\0str\0receiveMessage(QString)\0"
    "heartTimeOut()\0onQThreadFinished()\0"
    "obj\0onLocalThreadDestroy(QObject*)\0"
};

void Widget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        Widget *_t = static_cast<Widget *>(_o);
        switch (_id) {
        case 0: _t->onButtonQThreadClicked(); break;
        case 1: _t->onButtonClearBroswerClicked(); break;
        case 2: _t->onButtonQthread1SetSomethingClicked(); break;
        case 3: _t->onButtonQthread1GetSomethingClicked(); break;
        case 4: _t->onButtonQthreadQuitClicked(); break;
        case 5: _t->onButtonQthreadTerminateClicked(); break;
        case 6: _t->onButtonQThreadDoSomthingClicked(); break;
        case 7: _t->onButtonQThreadExitClicked(); break;
        case 8: _t->onButtonQThreadRunLoaclClicked(); break;
        case 9: _t->progress((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->receiveMessage((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 11: _t->heartTimeOut(); break;
        case 12: _t->onQThreadFinished(); break;
        case 13: _t->onLocalThreadDestroy((*reinterpret_cast< QObject*(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData Widget::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject Widget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_Widget,
      qt_meta_data_Widget, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Widget::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Widget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Widget::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Widget))
        return static_cast<void*>(const_cast< Widget*>(this));
    return QWidget::qt_metacast(_clname);
}

int Widget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
