/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QProgressBar>
#include <QtGui/QPushButton>
#include <QtGui/QTextBrowser>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QPushButton *pushButton_qthreadExit;
    QProgressBar *progressBar_heart;
    QPushButton *pushButton_qthreadQuit;
    QPushButton *pushButton_clear_broswer;
    QPushButton *pushButton_qthreadTerminate;
    QTextBrowser *textBrowser;
    QLabel *label_2;
    QProgressBar *progressBar;
    QLabel *label;
    QPushButton *pushButton_qthread1;
    QPushButton *pushButton_doSomthing;
    QPushButton *pushButton_qthreadRunLocal;
    QPushButton *pushButton_qthread1_getSomething;
    QPushButton *pushButton_qthread1_setSomething;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(800, 480);
        pushButton_qthreadExit = new QPushButton(Widget);
        pushButton_qthreadExit->setObjectName(QString::fromUtf8("pushButton_qthreadExit"));
        pushButton_qthreadExit->setGeometry(QRect(330, 10, 171, 31));
        progressBar_heart = new QProgressBar(Widget);
        progressBar_heart->setObjectName(QString::fromUtf8("progressBar_heart"));
        progressBar_heart->setGeometry(QRect(120, 130, 591, 23));
        progressBar_heart->setValue(24);
        pushButton_qthreadQuit = new QPushButton(Widget);
        pushButton_qthreadQuit->setObjectName(QString::fromUtf8("pushButton_qthreadQuit"));
        pushButton_qthreadQuit->setGeometry(QRect(120, 50, 171, 31));
        pushButton_clear_broswer = new QPushButton(Widget);
        pushButton_clear_broswer->setObjectName(QString::fromUtf8("pushButton_clear_broswer"));
        pushButton_clear_broswer->setGeometry(QRect(330, 90, 171, 31));
        pushButton_qthreadTerminate = new QPushButton(Widget);
        pushButton_qthreadTerminate->setObjectName(QString::fromUtf8("pushButton_qthreadTerminate"));
        pushButton_qthreadTerminate->setGeometry(QRect(120, 90, 171, 31));
        textBrowser = new QTextBrowser(Widget);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(20, 191, 761, 241));
        label_2 = new QLabel(Widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(60, 160, 51, 21));
        progressBar = new QProgressBar(Widget);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setGeometry(QRect(120, 160, 591, 23));
        progressBar->setValue(24);
        label = new QLabel(Widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 130, 71, 21));
        pushButton_qthread1 = new QPushButton(Widget);
        pushButton_qthread1->setObjectName(QString::fromUtf8("pushButton_qthread1"));
        pushButton_qthread1->setGeometry(QRect(120, 10, 171, 31));
        pushButton_doSomthing = new QPushButton(Widget);
        pushButton_doSomthing->setObjectName(QString::fromUtf8("pushButton_doSomthing"));
        pushButton_doSomthing->setGeometry(QRect(540, 90, 171, 31));
        pushButton_qthreadRunLocal = new QPushButton(Widget);
        pushButton_qthreadRunLocal->setObjectName(QString::fromUtf8("pushButton_qthreadRunLocal"));
        pushButton_qthreadRunLocal->setGeometry(QRect(330, 50, 171, 31));
        pushButton_qthread1_getSomething = new QPushButton(Widget);
        pushButton_qthread1_getSomething->setObjectName(QString::fromUtf8("pushButton_qthread1_getSomething"));
        pushButton_qthread1_getSomething->setGeometry(QRect(540, 10, 171, 31));
        pushButton_qthread1_setSomething = new QPushButton(Widget);
        pushButton_qthread1_setSomething->setObjectName(QString::fromUtf8("pushButton_qthread1_setSomething"));
        pushButton_qthread1_setSomething->setGeometry(QRect(540, 50, 171, 31));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", 0, QApplication::UnicodeUTF8));
        pushButton_qthreadExit->setText(QApplication::translate("Widget", "QThread exit", 0, QApplication::UnicodeUTF8));
        pushButton_qthreadQuit->setText(QApplication::translate("Widget", "QThread quit", 0, QApplication::UnicodeUTF8));
        pushButton_clear_broswer->setText(QApplication::translate("Widget", "Clear Browser", 0, QApplication::UnicodeUTF8));
        pushButton_qthreadTerminate->setText(QApplication::translate("Widget", "QThread Terminate", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("Widget", "thread", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("Widget", "heartbeat", 0, QApplication::UnicodeUTF8));
        pushButton_qthread1->setText(QApplication::translate("Widget", "QThread run", 0, QApplication::UnicodeUTF8));
        pushButton_doSomthing->setText(QApplication::translate("Widget", "do something", 0, QApplication::UnicodeUTF8));
        pushButton_qthreadRunLocal->setText(QApplication::translate("Widget", "QThread run local", 0, QApplication::UnicodeUTF8));
        pushButton_qthread1_getSomething->setText(QApplication::translate("Widget", "get something", 0, QApplication::UnicodeUTF8));
        pushButton_qthread1_setSomething->setText(QApplication::translate("Widget", "set something", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
