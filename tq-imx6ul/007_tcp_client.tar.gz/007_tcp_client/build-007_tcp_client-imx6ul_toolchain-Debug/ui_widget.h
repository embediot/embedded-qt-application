/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QTextBrowser>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QPushButton *pushButton_connect;
    QPushButton *pushButton_tx_clear;
    QPushButton *pushButton_send_data;
    QLabel *label_local_ip;
    QTextBrowser *textBrowser_rxdata;
    QLabel *label_title;
    QLabel *label_client_rxdata;
    QLabel *label_server_ip;
    QLabel *label_client_txdata;
    QTextBrowser *textBrowser_txdata;
    QPushButton *pushButton_rx_clear;
    QLineEdit *lineEdit_server_ip;
    QLabel *label_local_ip_display;
    QLabel *label_server_ip_2;
    QLineEdit *lineEdit_server_port;
    QLabel *label_connect_status;
    QPushButton *pushButton_auto_send_data;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(800, 480);
        pushButton_connect = new QPushButton(Widget);
        pushButton_connect->setObjectName(QString::fromUtf8("pushButton_connect"));
        pushButton_connect->setGeometry(QRect(460, 60, 111, 31));
        pushButton_tx_clear = new QPushButton(Widget);
        pushButton_tx_clear->setObjectName(QString::fromUtf8("pushButton_tx_clear"));
        pushButton_tx_clear->setGeometry(QRect(280, 110, 91, 25));
        pushButton_send_data = new QPushButton(Widget);
        pushButton_send_data->setObjectName(QString::fromUtf8("pushButton_send_data"));
        pushButton_send_data->setGeometry(QRect(220, 410, 151, 31));
        label_local_ip = new QLabel(Widget);
        label_local_ip->setObjectName(QString::fromUtf8("label_local_ip"));
        label_local_ip->setGeometry(QRect(460, 10, 121, 31));
        textBrowser_rxdata = new QTextBrowser(Widget);
        textBrowser_rxdata->setObjectName(QString::fromUtf8("textBrowser_rxdata"));
        textBrowser_rxdata->setGeometry(QRect(430, 140, 331, 251));
        label_title = new QLabel(Widget);
        label_title->setObjectName(QString::fromUtf8("label_title"));
        label_title->setGeometry(QRect(0, 0, 391, 41));
        label_client_rxdata = new QLabel(Widget);
        label_client_rxdata->setObjectName(QString::fromUtf8("label_client_rxdata"));
        label_client_rxdata->setGeometry(QRect(430, 110, 141, 31));
        label_server_ip = new QLabel(Widget);
        label_server_ip->setObjectName(QString::fromUtf8("label_server_ip"));
        label_server_ip->setGeometry(QRect(40, 60, 101, 31));
        label_client_txdata = new QLabel(Widget);
        label_client_txdata->setObjectName(QString::fromUtf8("label_client_txdata"));
        label_client_txdata->setGeometry(QRect(40, 110, 141, 31));
        textBrowser_txdata = new QTextBrowser(Widget);
        textBrowser_txdata->setObjectName(QString::fromUtf8("textBrowser_txdata"));
        textBrowser_txdata->setGeometry(QRect(40, 140, 331, 251));
        pushButton_rx_clear = new QPushButton(Widget);
        pushButton_rx_clear->setObjectName(QString::fromUtf8("pushButton_rx_clear"));
        pushButton_rx_clear->setGeometry(QRect(670, 110, 91, 25));
        lineEdit_server_ip = new QLineEdit(Widget);
        lineEdit_server_ip->setObjectName(QString::fromUtf8("lineEdit_server_ip"));
        lineEdit_server_ip->setGeometry(QRect(140, 60, 121, 31));
        lineEdit_server_ip->setAlignment(Qt::AlignCenter);
        label_local_ip_display = new QLabel(Widget);
        label_local_ip_display->setObjectName(QString::fromUtf8("label_local_ip_display"));
        label_local_ip_display->setGeometry(QRect(590, 10, 171, 31));
        label_local_ip_display->setFrameShape(QFrame::Box);
        label_local_ip_display->setFrameShadow(QFrame::Plain);
        label_local_ip_display->setAlignment(Qt::AlignCenter);
        label_server_ip_2 = new QLabel(Widget);
        label_server_ip_2->setObjectName(QString::fromUtf8("label_server_ip_2"));
        label_server_ip_2->setGeometry(QRect(270, 60, 111, 31));
        lineEdit_server_port = new QLineEdit(Widget);
        lineEdit_server_port->setObjectName(QString::fromUtf8("lineEdit_server_port"));
        lineEdit_server_port->setGeometry(QRect(390, 60, 61, 31));
        lineEdit_server_port->setAlignment(Qt::AlignCenter);
        label_connect_status = new QLabel(Widget);
        label_connect_status->setObjectName(QString::fromUtf8("label_connect_status"));
        label_connect_status->setGeometry(QRect(590, 60, 171, 31));
        label_connect_status->setFrameShape(QFrame::Box);
        label_connect_status->setFrameShadow(QFrame::Plain);
        label_connect_status->setAlignment(Qt::AlignCenter);
        pushButton_auto_send_data = new QPushButton(Widget);
        pushButton_auto_send_data->setObjectName(QString::fromUtf8("pushButton_auto_send_data"));
        pushButton_auto_send_data->setGeometry(QRect(40, 410, 151, 31));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", 0, QApplication::UnicodeUTF8));
        pushButton_connect->setText(QApplication::translate("Widget", "CONNECT", 0, QApplication::UnicodeUTF8));
        pushButton_tx_clear->setText(QApplication::translate("Widget", "TX_CLEAR", 0, QApplication::UnicodeUTF8));
        pushButton_send_data->setText(QApplication::translate("Widget", "tcp_send data", 0, QApplication::UnicodeUTF8));
        label_local_ip->setText(QApplication::translate("Widget", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">LOCAL_IP :</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_title->setText(QApplication::translate("Widget", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; font-weight:600;\">TCP Client Test</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_client_rxdata->setText(QApplication::translate("Widget", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">CLIENT_RX_DATA :</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_server_ip->setText(QApplication::translate("Widget", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">SERVER_IP:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_client_txdata->setText(QApplication::translate("Widget", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">CLIENT_TX_DATA :</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        pushButton_rx_clear->setText(QApplication::translate("Widget", "RX_CLEAR", 0, QApplication::UnicodeUTF8));
        lineEdit_server_ip->setText(QApplication::translate("Widget", "192.168.1.59", 0, QApplication::UnicodeUTF8));
        label_local_ip_display->setText(QString());
        label_server_ip_2->setText(QApplication::translate("Widget", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt;\">SERVER_PORT:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        lineEdit_server_port->setText(QApplication::translate("Widget", "4418", 0, QApplication::UnicodeUTF8));
        label_connect_status->setText(QString());
        pushButton_auto_send_data->setText(QApplication::translate("Widget", "START_AUTO_SEND", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
