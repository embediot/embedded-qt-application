/****************************************************************************
** Meta object code from reading C++ file 'tcp_client.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../007_tcp_client/tcp_socket/tcp_client/tcp_client.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'tcp_client.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_TCP_Client[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: signature, parameters, type, tag, flags
      21,   12,   11,   11, 0x05,
      67,   61,   11,   11, 0x05,

 // slots: signature, parameters, type, tag, flags
     108,   11,   11,   11, 0x0a,
     136,   11,   11,   11, 0x0a,
     167,   11,   11,   11, 0x0a,
     227,   11,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_TCP_Client[] = {
    "TCP_Client\0\0arr_data\0"
    "signal_tcp_client_recv_data(QByteArray)\0"
    "state\0signal_tcp_client_connect_state(QString)\0"
    "slot_tcp_client_connected()\0"
    "slot_tcp_client_disconnected()\0"
    "slot_tcp_client_connect_error(QAbstractSocket::SocketError)\0"
    "slot_tcp_client_recv_data()\0"
};

void TCP_Client::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        TCP_Client *_t = static_cast<TCP_Client *>(_o);
        switch (_id) {
        case 0: _t->signal_tcp_client_recv_data((*reinterpret_cast< QByteArray(*)>(_a[1]))); break;
        case 1: _t->signal_tcp_client_connect_state((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->slot_tcp_client_connected(); break;
        case 3: _t->slot_tcp_client_disconnected(); break;
        case 4: _t->slot_tcp_client_connect_error((*reinterpret_cast< QAbstractSocket::SocketError(*)>(_a[1]))); break;
        case 5: _t->slot_tcp_client_recv_data(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData TCP_Client::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject TCP_Client::staticMetaObject = {
    { &QTcpSocket::staticMetaObject, qt_meta_stringdata_TCP_Client,
      qt_meta_data_TCP_Client, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &TCP_Client::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *TCP_Client::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *TCP_Client::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_TCP_Client))
        return static_cast<void*>(const_cast< TCP_Client*>(this));
    return QTcpSocket::qt_metacast(_clname);
}

int TCP_Client::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTcpSocket::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    }
    return _id;
}

// SIGNAL 0
void TCP_Client::signal_tcp_client_recv_data(QByteArray _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void TCP_Client::signal_tcp_client_connect_state(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_END_MOC_NAMESPACE
