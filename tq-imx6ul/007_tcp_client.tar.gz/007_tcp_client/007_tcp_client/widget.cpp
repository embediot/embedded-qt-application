#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    ui->pushButton_connect->setCheckable(false);
    ui->pushButton_auto_send_data->setCheckable(false);

    ui->pushButton_send_data->setEnabled(false);         //手动发送数据按钮不可用
    ui->pushButton_auto_send_data->setEnabled(false);    //自动发送数据按钮不可用

    ui->lineEdit_server_ip->setEnabled(true);  //服务器IP可以被输入
    ui->lineEdit_server_port->setEnabled(true); //服务器端口可以被输入

    tcp_client = new TCP_Client();  //创建一个TCP_Client类对象

    ui->label_local_ip_display->setText(tcp_client->get_local_ipaddr());   //显示本机的IP地址

    //连接信号槽，用来处理TCP客户端的连接状态
    connect(tcp_client,SIGNAL(signal_tcp_client_connect_state(QString)),this,SLOT(slot_tcp_client_connect_state(QString)));

    //连接信号槽，用来处理TCP客户端接收到的数据
    connect(tcp_client,SIGNAL(signal_tcp_client_recv_data(QByteArray)),this,SLOT(slot_tcp_client_recv_data(QByteArray)));

    auto_send_timer = new QTimer();     //构建一个TCP自动发送数据的定时器
    connect( auto_send_timer, SIGNAL(timeout()), this, SLOT(slot_auto_send_timer_handler()));  //关联定时器超时槽函数
}

Widget::~Widget()
{
    tcp_client->disconnect_server();    //断开服务器连接
    tcp_client->deleteLater();   //删除TCP客户端对象
    delete auto_send_timer;
    delete ui;
}

//显示发送的数据内容
void Widget::display_tcp_client_tx_data(QString str_data)
{
    //QString str_display = "[device --> pc] ";
    ui->textBrowser_txdata->append(str_data);
}

//显示接收的数据内容
void Widget::display_tcp_client_rx_data(QString str_data)
{
    //QString str_display = "[pc --> device] ";
    ui->textBrowser_rxdata->append(str_data);
}

//点击此按钮，连接服务器
void Widget::on_pushButton_connect_clicked()
{
    QString server_ip;
    int server_port;
    bool ok;

    if(ui->pushButton_connect->isCheckable())      //客户端处于断开状态
    {

        ui->pushButton_connect->setCheckable(false);
        ui->pushButton_connect->setText(trUtf8("CONNECT"));

        ui->lineEdit_server_ip->setEnabled(true);
        ui->lineEdit_server_port->setEnabled(true);

        tcp_client->disconnect_server();
    }
    else     //客户端处于连接状态
    {
        if(ui->lineEdit_server_ip->text().isEmpty() || ui->lineEdit_server_port->text().isEmpty())   //检查服务器IP和服务器端口是否参数有效
        {
            ui->label_connect_status->setText(QString("params error!"));
            QMessageBox::information(this,"Server Params","Server Params Error!");
            return;
        }
        else
        {
            server_ip = ui->lineEdit_server_ip->text();
            server_port = ui->lineEdit_server_port->text().toInt(&ok,10);

            tcp_client->connect_server(server_ip,server_port);   //根据指定的ip和端口，连接服务器
        }
    }
}

//客户端连接状态的信号槽
void Widget::slot_tcp_client_connect_state(QString state)
{
    if(state == TCP_CONNECTED)    //TCP客户端处于连接状态
    {
        ui->pushButton_connect->setCheckable(true);
        ui->pushButton_connect->setText(trUtf8("DISCONNECT"));

        //连接成功后，服务器的IP和端口不可以再被编辑
        ui->lineEdit_server_ip->setEnabled(false);
        ui->lineEdit_server_port->setEnabled(false);

        //连接成功后，客户端的发送数据按钮和自动发送按钮可被使用
        ui->pushButton_send_data->setEnabled(true);
        ui->pushButton_auto_send_data->setEnabled(true);

        ui->label_connect_status->setText("connect success");
    }
    else if(state == TCP_DISCONNECTED)   //TCP客户端处于断开状态
    {
        ui->pushButton_connect->setCheckable(false);
        ui->pushButton_connect->setText(trUtf8("CONNECT"));

        //连接断开后，服务器的IP和端口可以再被编辑
        ui->lineEdit_server_ip->setEnabled(true);
        ui->lineEdit_server_port->setEnabled(true);

        //连接断开后，客户端的发送数据按钮和自动发送按钮不可被使用
        ui->pushButton_send_data->setEnabled(false);
        ui->pushButton_auto_send_data->setEnabled(false);

        //自动发送定时器要关闭
        ui->pushButton_auto_send_data->setCheckable(false);
        ui->pushButton_auto_send_data->setText(trUtf8("START_AUTO_SEND"));

        auto_send_timer->stop();

        ui->label_connect_status->setText("disconnect success");

    }
    else if(state == TCP_CONNECT_ERROR)   //TCP客户端连接出错
    {
        ui->pushButton_connect->setCheckable(false);
        ui->pushButton_connect->setText(trUtf8("CONNECT"));

        ui->lineEdit_server_ip->setEnabled(true);
        ui->lineEdit_server_port->setEnabled(true);

        ui->pushButton_send_data->setEnabled(false);
        ui->pushButton_auto_send_data->setEnabled(false);

        ui->label_connect_status->setText("connect error");
    }

}

//处理TCP客户端接收到的数据
void Widget::slot_tcp_client_recv_data(QByteArray data_recv)
{
    QString str_display;

    str_display.prepend(data_recv);

    display_tcp_client_rx_data(str_display);   //显示TCP客户端接收到的数据
}

//手动发送数据按钮
void Widget::on_pushButton_send_data_clicked()
{
    tcp_client->tcp_client_send_data(QString("helloworld"));

    display_tcp_client_tx_data(QString("helloworld"));
}

//清空发送数据显示框
void Widget::on_pushButton_tx_clear_clicked()
{
    ui->textBrowser_txdata->clear();
}

//清空接收数据显示框
void Widget::on_pushButton_rx_clear_clicked()
{
    ui->textBrowser_rxdata->clear();
}

//自动发送数据按钮
void Widget::on_pushButton_auto_send_data_clicked()
{
    if(ui->pushButton_auto_send_data->isCheckable())
    {
        ui->pushButton_auto_send_data->setCheckable(false);
        ui->pushButton_auto_send_data->setText(trUtf8("START_AUTO_SEND"));

        auto_send_timer->stop();   //关停定时器
    }
    else
    {
        ui->pushButton_auto_send_data->setCheckable(true);
        ui->pushButton_auto_send_data->setText(trUtf8("STOP_AUTO_SEND"));

        auto_send_timer->start(1000);   //启动定时器，以1秒的频率自动发送数据
    }
}

//通过定时器超时，自动发送数据
void Widget::slot_auto_send_timer_handler()
{
    tcp_client->tcp_client_send_data(QString("[auto send] helloworld"));

    display_tcp_client_tx_data(QString("[auto send] helloworld"));
}
