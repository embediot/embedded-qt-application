#ifndef __TCP_CLIENT_H_
#define __TCP_CLIENT_H_


#include <QTcpSocket>
#include <QHostAddress>
#include <QNetworkInterface>


#define TCP_CONNECTED        "CONNECTED"
#define TCP_DISCONNECTED     "DISCONNECTED"
#define TCP_CONNECT_ERROR    "CONNECT_ERROR"

class TCP_Client : public QTcpSocket
{
    Q_OBJECT

public:
    TCP_Client(QObject* parent=0);
    ~TCP_Client();

    QString get_local_ipaddr(void);   //获取本机的IP地址
    void connect_server(QString server_ip, int server_port);   //连接服务器函数
    void disconnect_server(void);  //断开与服务器的连接

    void tcp_client_send_data(QByteArray arr_data);    //客户端向服务器发送数据
    void tcp_client_send_data(QString str_data);    //客户端向服务器发送数据

public slots:
    void slot_tcp_client_connected(void);  //客户端连接成功的槽函数
    void slot_tcp_client_disconnected(void);  //客户端断开连接的槽函数
    void slot_tcp_client_connect_error(QAbstractSocket::SocketError);   //客户端连接出错的槽函数
    void slot_tcp_client_recv_data();   //客户端从服务器接收数据

signals:
    void signal_tcp_client_recv_data(QByteArray arr_data);  //发送此信号，通知widget类处理接收到的服务端数据
    void signal_tcp_client_connect_state(QString state);   //发送此信号，通知widget类关于TCP-Client的连接状态

private:

    QTcpSocket *m_tcp_socket;  //QTcpSocket对象，用来进行网络操作
};







#endif
