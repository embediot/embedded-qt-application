#include "tcp_client.h"


//TCP_Client的构造函数
TCP_Client::TCP_Client(QObject* parent) : QTcpSocket(parent)
{
    m_tcp_socket = new QTcpSocket();


}


//TCP_Client的析构函数
TCP_Client::~TCP_Client()
{
    delete m_tcp_socket;
    m_tcp_socket = NULL;
}

//获取本机的IP地址
QString TCP_Client::get_local_ipaddr(void)
{
    QString ip_addr;
    QList<QHostAddress> ip_addr_list = QNetworkInterface::allAddresses();  //获取本机所有的IP地址列表

    for (int i = 0; i < ip_addr_list.size(); ++i)  //对IP地址进行筛选，只取IPv4的地址
    {
        if(ip_addr_list.at(i) != QHostAddress::LocalHost &&  ip_addr_list.at(i).toIPv4Address())
        {
            ip_addr = ip_addr_list.at(i).toString();
            break;
        }
    }

    //如果IP地址为空，那就取127.0.0.0作为地址
    if (ip_addr.isEmpty())ip_addr = QHostAddress(QHostAddress::LocalHost).toString();

    return ip_addr;
}

//连接服务器函数
void TCP_Client::connect_server(QString server_ip,int server_port)
{
    if(m_tcp_socket)
    {
        m_tcp_socket->connectToHost(server_ip,server_port,QTcpSocket::ReadWrite); //尝试连接服务器

        //建立信号槽，接收连接成功的信号
        connect(m_tcp_socket,SIGNAL(connected()),this,SLOT(slot_tcp_client_connected()));
        //建立信号槽，接收连接失败的信号
        connect(m_tcp_socket,SIGNAL(error(QAbstractSocket::SocketError)),this,SLOT(slot_tcp_client_connect_error(QAbstractSocket::SocketError)));

    }
}

//断开与服务器的连接
void TCP_Client::disconnect_server(void)
{
    if(m_tcp_socket)
        m_tcp_socket->disconnectFromHost();   //断开与服务器的连接
}

//客户端向服务器发送数据，以QByteArray发送
void TCP_Client::tcp_client_send_data(QByteArray arr_data)
{
    if(m_tcp_socket)
        m_tcp_socket->write(arr_data);
}

//客户端向服务器发送数据，以QString格式发送
void TCP_Client::tcp_client_send_data(QString str_data)
{
    if(m_tcp_socket)
        m_tcp_socket->write(str_data.toLatin1().data(),str_data.length());
}
//客户端连接成功的槽函数
void TCP_Client::slot_tcp_client_connected(void)
{
     //建立信号槽，接收连接断开信号
     connect(m_tcp_socket,SIGNAL(disconnected()),this,SLOT(slot_tcp_client_disconnected()));
     //建立信号槽，接收读取数据信号
     connect(m_tcp_socket,SIGNAL(readyRead()),this,SLOT(slot_tcp_client_recv_data()));

     emit signal_tcp_client_connect_state(TCP_CONNECTED);
}

//客户端断开连接的槽函数
void TCP_Client::slot_tcp_client_disconnected(void)
{
    qDebug() << ">>> slot_tcp_client_disconnected >>>";

    emit signal_tcp_client_connect_state(TCP_DISCONNECTED);
}

//客户端连接出错的槽函数
void TCP_Client::slot_tcp_client_connect_error(QAbstractSocket::SocketError)
{
    qDebug() << ">>> slot_tcp_client_connect_error >>>";
    emit signal_tcp_client_connect_state(TCP_CONNECT_ERROR);
}

 //客户端从服务器接收数据
void TCP_Client::slot_tcp_client_recv_data()
{
    //qDebug() << ">>> void TCP_Client::slot_tcp_client_recv_data() >>>";
    QByteArray arr_data_recv;

    arr_data_recv.resize(m_tcp_socket->bytesAvailable());

    arr_data_recv = m_tcp_socket->readAll();

    emit signal_tcp_client_recv_data(arr_data_recv);
}
