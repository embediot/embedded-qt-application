#ifndef __TCP_SERVER_H_
#define __TCP_SERVER_H_


#include <QtNetwork>
#include <QTcpServer>
#include <QStringList>
#include "tcp_socket.h"


class TcpServer : public QTcpServer
{
    Q_OBJECT

public:
    TcpServer(QObject *parent = 0,int port=0);

    QList<TcpSocket*> tcp_socket_list;
    QStringList peer_address;
    QString local_ip_addr;
    int local_port;

    void push_message();
    void tcp_server_write_data(QByteArray arr, int socket_desc);
    QStringList get_peer_address(void);

signals:
    void signal_receive_data(QString,int,int);
    void signal_receive_data(QByteArray,int);

    void signal_new_connection();
public slots:
    void slot_receive_data(QString msg, int length,int socket_desc);
    void slot_receive_data(QByteArray arr, int socket_desc);
    void slot_disconnected(int);

protected:
    void incomingConnection(qintptr socket_descriptor);

private:
    QStringList fortunes;
    int online_descriptor;

};




#endif
