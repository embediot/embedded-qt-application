#include "tcp_server.h"
#include <stdlib.h>

TcpServer::TcpServer(QObject *parent,int port)
        : QTcpServer(parent)
{

    QString ip_addr;
    QList<QHostAddress> ip_addr_list = QNetworkInterface::allAddresses();

    for (int i = 0; i < ip_addr_list.size(); ++i)
    {
        if(ip_addr_list.at(i) != QHostAddress::LocalHost &&  ip_addr_list.at(i).toIPv4Address())
        {
            ip_addr = ip_addr_list.at(i).toString();
            local_ip_addr = ip_addr;
            local_port = port;
            break;
        }
    }
    if (ip_addr.isEmpty())ip_addr = QHostAddress(QHostAddress::LocalHost).toString();

    ip_addr = QString("0.0.0.0");
    //qDebug() << "the tcp server ip = " << ip_addr;

    this->listen(QHostAddress(ip_addr),port);
}

void TcpServer::incomingConnection(qintptr socket_descriptor)
{
    TcpSocket *tcp_client_socket = new TcpSocket(this);
    QString peer_addr;

    tcp_client_socket->setSocketDescriptor(socket_descriptor);

    peer_addr = tcp_client_socket->peerAddress().toString();

    if(peer_address.contains(peer_addr) == false)  //如果不包含新连接的ip
    {
        //connect(tcp_client_socket,SIGNAL(signal_receive_data(QString,int,int)),this,SLOT(slot_receive_data(QString,int,int)));
        connect(tcp_client_socket,SIGNAL(signal_receive_data(QByteArray,int)),this,SLOT(slot_receive_data(QByteArray,int)));
        connect(tcp_client_socket,SIGNAL(signal_disconnected(int)),this,SLOT(slot_disconnected(int)));

        tcp_socket_list.append(tcp_client_socket);
        peer_address.append(tcp_client_socket->peerAddress().toString());

        emit signal_new_connection();
    }
    else
    {
        if(tcp_client_socket)delete tcp_client_socket;
    }

/*
    onlineDescriptor=socketDescriptor;
    QString fortune = fortunes.at(qrand() % fortunes.size());
//    QString fortune = fortunes.at(0);
    ChatThread *thread = new ChatThread(socketDescriptor, fortune, this);
    connect(thread, SIGNAL(finished()), thread, SLOT(deleteLater()));
    thread->start();
*/
}


void TcpServer::slot_receive_data(QString msg, int length,int socket_desc)
{
    //qDebug() << msg.toLocal8Bit().data() << msg.toLatin1().toHex();
    emit signal_receive_data(msg,length,socket_desc);
}

void TcpServer::slot_receive_data(QByteArray arr,int socket_desc)
{ 
    emit signal_receive_data(arr,socket_desc);
}



void TcpServer::slot_disconnected(int descriptor)
{
    for (int i=0;i < tcp_socket_list.count();i++)
    {
        QTcpSocket *item = tcp_socket_list.at(i);

        if(item->socketDescriptor() == descriptor)
        {
            tcp_socket_list.removeAt(i);
            peer_address.removeAt(i);
            return;
        }
    }
    return;
}

void TcpServer::tcp_server_write_data(QByteArray arr,int socket_desc)
{
    for (int i=0;i < tcp_socket_list.count();i++)
    {
        QTcpSocket *item = tcp_socket_list.at(i);

        if(item->socketDescriptor() == socket_desc)
        {
            item->write(arr);
        }
    }
}

void TcpServer::push_message()
{

}

QStringList TcpServer::get_peer_address(void)
{
    return peer_address;
}



