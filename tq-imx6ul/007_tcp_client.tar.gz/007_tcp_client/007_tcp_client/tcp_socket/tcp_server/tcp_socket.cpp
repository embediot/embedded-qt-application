#include "tcp_socket.h"



TcpSocket::TcpSocket(QObject* parent) : QTcpSocket(parent)
{    
    connect(this,SIGNAL(readyRead()),this,SLOT(slot_data_received()));
    connect(this,SIGNAL(disconnected()),this,SLOT(slot_disconnected()));

    tcp_recv_timeout = new QTimer();
    connect( tcp_recv_timeout, SIGNAL(timeout()), this, SLOT(slot_tcp_recv_timeout()));
    tcp_recv_timeout->setSingleShot(true);

    recv_count = 0;
}

TcpSocket::~TcpSocket()
{

}



void TcpSocket::slot_data_received()
{
#if 0
    while(bytesAvailable() > 0)
    {
        char buf[1024];
        int length = bytesAvailable();

        read(buf,length);

        QString msg = buf;

        emit signal_receive_data(msg,length,this->socketDescriptor());

    }
#else
    QByteArray arr;
    //QString str_recv;

    arr = this->readAll();
    emit signal_receive_data(arr,this->socketDescriptor());

//    recv_count += arr.length();

//    tcp_recv_all.append(QString(arr.data()));

//    tcp_recv_timeout->start(200);
#endif
}

void TcpSocket::slot_tcp_recv_timeout()
{
    recv_count = 0;
    emit signal_receive_data(tcp_recv_all,this->socketDescriptor());
}

void TcpSocket::slot_disconnected()
{
    emit signal_disconnected(this->socketDescriptor());
}
