#ifndef __TCP_SOCKET_H_
#define __TCP_SOCKET_H_


#include <QTcpSocket>
#include <QTimer>

class TcpSocket : public QTcpSocket
{
    Q_OBJECT

public:
    TcpSocket(QObject* parent=0);
    ~TcpSocket();

signals:
    void signal_receive_data(QString,int,int);
    void signal_receive_data(QByteArray,int);
    void signal_disconnected(int);

protected slots:
    void slot_data_received();
    void slot_disconnected();
    void slot_tcp_recv_timeout();

private:
    QByteArray tcp_recv_all;
    QTimer *tcp_recv_timeout;
    int recv_count;
};







#endif

