#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTimer>
#include <QMessageBox>
#include <tcp_socket/tcp_client/tcp_client.h>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

    void display_tcp_client_tx_data(QString str_data);     //显示TCP客户端发送的数据
    void display_tcp_client_rx_data(QString str_data);     //显示TCP客户端接收到的数据

private slots: 
    void slot_tcp_client_connect_state(QString state);     //TCP客户端连接状态的槽函数
    void slot_tcp_client_recv_data(QByteArray data_recv);  //TCP客户端接收数据处理的槽函数
    void slot_auto_send_timer_handler();       //通过定时器超时，自动发送数据
    void on_pushButton_connect_clicked();      //TCP客户端连接服务器的按钮
    void on_pushButton_send_data_clicked();    //手动发送数据的按钮
    void on_pushButton_tx_clear_clicked();     //清空发送数据显示框的按钮
    void on_pushButton_rx_clear_clicked();     //清空接收数据显示框的按钮
    void on_pushButton_auto_send_data_clicked();  //自动发送数据的按钮

private:
    Ui::Widget *ui;

    TCP_Client *tcp_client;    //TCP客户端对象
    QTimer *auto_send_timer;   //数据自动发送定时器
};

#endif // WIDGET_H
